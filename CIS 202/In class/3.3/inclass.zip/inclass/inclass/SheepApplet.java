package inclass;

import javax.swing.JApplet;
import java.awt.*;

public class SheepApplet extends JApplet {

	private Sheep giancario;
	private Sheep kahala;
	private Sheep kari;
	
	@Override
	public void init() {
		giancario = new Sheep();
		kahala = new Sheep(300,400);
		Color kahalaColor = kahala.getColor();
		System.out.println(kahalaColor);
		kari = new Sheep(Color.BLUE);
		kari.move(500,30);
		System.out.println(kari.getColor());
	}
	
	@Override
	public void paint(Graphics g) {
		int w = getWidth();
		int h = getHeight();

		//draw a green background
		g.setColor(Color.GREEN);
		g.fillRect(0,0,w,h);
	
//		Vertex lito = new Vertex(100,200);
//		drawSheep(g, lito);
//		Vertex gabriel = new Vertex(lito);
//		gabriel.x += 400;
//		drawSheep(g, gabriel);
		giancario.move(5,0);
		giancario.draw(g);
		kahala.draw(g);
		kari.draw(g);
		
		Sheep kahala = new Sheep(300,400);
		kahala.draw(g);
		
		kari = new Sheep(Color.BLUE);
		kari.move(500,30);
		kari.draw(g);
	}
	
	

}

