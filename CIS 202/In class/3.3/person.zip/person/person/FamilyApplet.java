package person;

import javax.swing.JApplet;

public class FamilyApplet extends JApplet{
	private Person p1;
	private Person p2;
	
	public void init() {
		p1 = new Person("Reyna");
		p2 = new Person("Scott");
	}
	
}
