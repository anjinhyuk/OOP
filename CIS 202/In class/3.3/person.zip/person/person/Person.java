package person;

import java.awt.Color;

public class Person {
	private String name;
	private int age;
	private Color favoriteColor;
	private char gender;
	private double height; //in centimeters;
	
	public Person() {
		name = "Untel";
		age = 0;
		favoriteColor = Color.GREEN;
		gender = 'u';
		height = 157;
	}
	
	public Person(String n) {
		this();
		name = "n";
	}
	
	public Person (String n, int a) {
		this(n);
		age = a;
	}
	
	public Person(String n, int a, char g) {
		this(n,a);
		gender = g;
	}
	
	public void printInfo() {
		System.out.println("My name is " + name);
		System.out.println("I am " + age + " years old");
		System.out.println("My favorite Color's RGB value is " + favoriteColor);
		System.out.println("My gender is " + gender);
		System.out.println("My eight is " + height + "cm");
	}
}
