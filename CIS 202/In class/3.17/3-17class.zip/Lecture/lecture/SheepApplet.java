package lecture;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SheepApplet extends JApplet implements KeyListener {

	//private Sheep giancarlo;
	private Sheep kahala;
	//private Sheep kari;
	
	@Override
	public void init() {
		//giancarlo = new Sheep();
		kahala = new Sheep(300,400);
		Color kahalaColor = kahala.getColor();
		System.out.println(kahalaColor);
		addKeyListener(this);
//		kari = new Sheep(Color.BLUE);
//		kari.move(500,30);
//		System.out.println(kari.getColor());
	}
	
	@Override
	public void paint(Graphics g) {
		//use keyboard
		requestFocusInWindow();
		int w = getWidth();
		int h = getHeight();

		//draw a green background
		g.setColor(Color.GREEN);
		g.fillRect(0,0,w,h);
		
		//draw those three sheep!
		//giancarlo.move(5, 0);
		//giancarlo.draw(g);
		kahala.draw(g);
		//kari.draw(g);
		
	}
	
	public void keyPressed(KeyEvent e){
//		char mander = e.getKeyChar();
//		System.out.println(mander);
		int k = e.getKeyCode();
		if (k == KeyEvent.VK_UP) {
			kahala.move(0, -5);
		}
		if (k == KeyEvent.VK_RIGHT) {
			kahala.move(5, 0);
		}
		if (k == KeyEvent.VK_LEFT) {
			kahala.move(-5, 0);
		}
		if (k == KeyEvent.VK_DOWN) {
			kahala.move(0, 5);
		}
		repaint();
	}
	
	public void keyReleased(KeyEvent e) {}
	
	public void keyTyped(KeyEvent e) {}
}

