package familyTree;

import java.awt.*;
import javax.swing.*;


public class FamilyApplet extends JApplet {

	private Person p1;
	private Person p2;
	private Person p3;
	private Person p4;
	
	//preparing
	public void init() {
		p1 = new Person("Janis"); //first new variable
		p1.setPicture("janis.gif"); //bring the file name
		p2 = new Person("David");
		p3 = new Person("Maria");
		p4 = new Person("Geoff");
		p4.setMother(p1);
		p4.setFather(p2);
		p4.setSpouse(p3);
		p4.printInfo();
	}
	//acting
	@Override
	public void paint(Graphics g) {
		p1.draw(g, 100, 100);
		p2.draw(g, 300, 300);

	}
}
