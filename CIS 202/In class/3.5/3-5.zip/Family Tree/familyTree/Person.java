package familyTree;

import java.awt.*;
import javax.swing.*;


public class Person {
	private String name;
	private int age;
	private Color favoriteColor;
	private char gender;
	private double height; //in centimeters;
	private ImageIcon picture;
	
	//separate object (Object preference)
	private Person mother;
	private Person father;
	private Person spouse;
	private Person child;
	
	public void setMother (Person p) {
		mother = p;
		p.child = this;
	}
	
	public void setFather(Person p) {
		father = p;
	}
	
	public void setSpouse(Person p) {
		this.spouse = p;
		p.spouse = this;
	}
	
	
	public Person() {
		name = "Untel";
		age = 0;
		favoriteColor = Color.GREEN;
		gender = 'u';
		height = 157;
	}
	//default
	//this() is bringing the info from the previous
	public Person(String n) {
		this();
		name = n;
	}
	
	public Person(String n, int a) {
		this(n);
		age = a;
	}
	
	public Person(String n, int a, char g) {
		this(n,a);
		gender = g;
	}
	
	public void setPicture (String filename) { //declare the new of file
		picture = new ImageIcon(filename);
	}
	
	public void printInfo() {
		System.out.println("My name is " + name);
		System.out.println("My mother is " + mother.name);
		System.out.println("My father is " + father.name);
		System.out.println("My spouse is " + spouse.name);
//		System.out.println("I am " + age + " years old");
//		System.out.println("My favorite color's RGB value is " + favoriteColor);
//		System.out.println("My gender is " + gender);
//		System.out.println("And I am " + height + " cm tall");
	}
	
	public void draw(Graphics g, int x, int y) { //drawing method to call the picture file
		if (picture != null){ //null pointer check! avoid N.P.E
			picture.paintIcon(null,g,x,y);
		} else {
			g.drawString(name, x, y);
		}
	}
}
