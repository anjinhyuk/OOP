import java.awt.*;
import javax.swing.*;

//David image class
public class David extends Sprite{
	
	public David() {
		image = new ImageIcon("David.png");
	}
}