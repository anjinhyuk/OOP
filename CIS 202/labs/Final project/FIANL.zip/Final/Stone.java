import java.awt.*;
import javax.swing.*;

//Stone image class
public class Stone extends Sprite{
	
	public Stone() {
		super();
	image = new ImageIcon("Stone.png");
	}
}
