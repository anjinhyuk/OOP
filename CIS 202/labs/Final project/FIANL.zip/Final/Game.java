import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.*;
import java.util.Timer;
import java.applet.AudioClip;
import java.io.File;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.swing.*;

public class Game extends JPanel implements KeyListener {
	private Room room1;
	private Room room2;
	private Room room3;
	private Room room4;
	private Room room5;
	private Room room6;
	private Room room7;
	private Room room8;
	private Room room9;
	private Room room10;
	private Room room11;
	private Room room12;
	private Room room13;
	private Room room14;
	private Room room15;
	private Room room16;
	private Room room17;
	private Room room18;
	private Room room19;
	private Room room20;
	private Room room21;
	private Room room22;
	private Room room23;
	private Room room24;
	private Room room25;
	//use sprite images
	private David david;
	private Goliath goliath;
	private Stone stone1;
	private Stone stone2;
	private Stone stone3;
	private Stone stone4;
	private Stone stone5;
	
	//arraylist for stones and rooms
	ArrayList<Stone> rock = new ArrayList<Stone>();
	ArrayList<Drawable> rooms = new ArrayList<>();
	
	//background music method
	public void musicPlay() {
		try {
			AudioInputStream audioInputStream = AudioSystem.getAudioInputStream(new File("bg.wav").getAbsoluteFile());
			Clip clip = AudioSystem.getClip();
			clip.open(audioInputStream);
			clip.start();
			
		} catch (Exception ex) {
			System.out.println("Dang it!");
			ex.printStackTrace();
		}
	}
	
	//Timer
	Timer timer = new Timer();	

	public Game() {
		musicPlay();
		//ROOMS
		room1 = new Room(0,0);
		room2 = new Room(60,0);
		room3 = new Room(0,60);
		room4 = new Room(60,60);
		room5 = new Room(0,120);
		room6 = new Room(60,120);
		room7 = new Room(0,180);
		room8 = new Room(60,180);
		room9 = new Room(0,240);
		room10 = new Room(60,240);
		room11 = new Room(120,120);
		room12 = new Room(180,60);
		room13 = new Room(180,120);
		room14 = new Room(180,180);
		room15 = new Room(240,120);
		room16 = new Room(300,0);
		room17 = new Room(360,0);
		room18 = new Room(300,60);
		room19 = new Room(360,60);
		room20 = new Room(300,120);
		room21 = new Room(360,120);
		room22 = new Room(300,180);
		room23 = new Room(360,180);
		room24 = new Room(300,240);
		room25 = new Room(360,240);
		//initiate icons
		david = new David();
		goliath = new Goliath();
		stone1 = new Stone();
		stone2 = new Stone();
		stone3 = new Stone();
		stone4 = new Stone();
		stone5 = new Stone();
		//add stones in the arraylist
		rock.add(stone1);
		rock.add(stone2);
		rock.add(stone3);
		rock.add(stone4);
		rock.add(stone5);
		//PATH 1-10
		room1.setSouthExit(room3);
		room1.setEastExit(room2);
		room2.setSouthExit(room4);
		room4.setSouthExit(room6);
		room5.setEastExit(room6);
		room6.setEastExit(room11);
		room6.setSouthExit(room8);
		room8.setSouthExit(room10);
		room10.setWestExit(room9);
		room7.setSouthExit(room9);
		//PATH 11-20
		room11.setEastExit(room13);
		room13.setNorthExit(room12);
		room13.setSouthExit(room14);
		room13.setEastExit(room15);
		room15.setEastExit(room20);
		room18.setSouthExit(room20);
		room16.setSouthExit(room18);
		room16.setEastExit(room17);
		room17.setSouthExit(room19);
		room19.setSouthExit(room21);
		//PATH 21-25
		room20.setSouthExit(room22);
		room22.setSouthExit(room24);
		room24.setEastExit(room25);
		room23.setSouthExit(room25);
		room22.setEastExit(room23);
		//Room set for icons
		david.setCurrentRoom(room1);
		goliath.setCurrentRoom(room25);
		stone1.setCurrentRoom(room5);
		stone2.setCurrentRoom(room7);
		stone3.setCurrentRoom(room12);
		stone4.setCurrentRoom(room19);
		stone5.setCurrentRoom(room23);
		//rooms
		rooms.add(room1);
		rooms.add(room2);
		rooms.add(room3);
		rooms.add(room4);
		rooms.add(room5);
		rooms.add(room6);
		rooms.add(room7);
		rooms.add(room8);
		rooms.add(room9);
		rooms.add(room10);
		rooms.add(room11);
		rooms.add(room12);
		rooms.add(room13);
		rooms.add(room14);
		rooms.add(room15);
		rooms.add(room16);
		rooms.add(room17);
		rooms.add(room18);
		rooms.add(room19);
		rooms.add(room20);
		rooms.add(room21);
		rooms.add(room22);
		rooms.add(room23);
		rooms.add(room24);
		rooms.add(room25);
		rooms.add(rock.get(0));
		rooms.add(rock.get(1));
		rooms.add(rock.get(2));
		rooms.add(rock.get(3));
		rooms.add(rock.get(4));
		rooms.add(david);
		rooms.add(goliath);
		
		//interface 
		addKeyListener(this);
		
	}
	
	//background setting
	@Override
	public void paint (Graphics g) {
		int w = getWidth();
	    int h = getHeight();
	    g.setColor(Color.BLACK);
	    g.fillRect(0, 0, w, h);
	    //draw rooms
	    
	    for (Drawable a:rooms) {
	    	a.draw(g);
	    }
	    
	    //to be safe
	    requestFocusInWindow();
	}
	//reset theory
	private void reset() {
		
		Random rand = new Random();
		
		for (int i=0;i<5;i++) {
			rock.add(new Stone());
		}
		
		goliath.setCurrentRoom((Room) rooms.get(rand.nextInt(3)));
		david.setCurrentRoom((Room) rooms.get(rand.nextInt(3) + 4));
		rock.get(0).setCurrentRoom((Room) rooms.get(rand.nextInt(3) + 8));
		rock.get(1).setCurrentRoom((Room) rooms.get(rand.nextInt(3) + 12));
		rock.get(2).setCurrentRoom((Room) rooms.get(rand.nextInt(2) + 16));
		rock.get(3).setCurrentRoom((Room) rooms.get(rand.nextInt(2) + 19));
		rock.get(4).setCurrentRoom((Room) rooms.get(rand.nextInt(2) + 22));
		
		david.reset();
	}
	
	//key pressed method to make characters move
	@Override
	public void keyPressed(KeyEvent e) {
		int k = e.getKeyCode();
		
		if (k == KeyEvent.VK_UP) {
			david.moveNorth();
		}
		if (k == KeyEvent.VK_DOWN) {
			david.moveSouth();
		}
		if (k == KeyEvent.VK_LEFT) {
			david.moveWest();
		}
		if (k == KeyEvent.VK_RIGHT) {
			david.moveEast();
		}
		if (k == KeyEvent.VK_NUMPAD8) {
			david.moveNorth();
		}
		if (k == KeyEvent.VK_NUMPAD4) {
			david.moveWest();
		}
		if (k == KeyEvent.VK_NUMPAD6) {
			david.moveEast();
		}
		if (k == KeyEvent.VK_NUMPAD2) {
			david.moveSouth();
		}
		if (k == KeyEvent.VK_W) {
			goliath.moveNorth();
		}
		if (k == KeyEvent.VK_S) {
			goliath.moveSouth();
		}
		if (k == KeyEvent.VK_A) {
			goliath.moveWest();
		}
		if (k == KeyEvent.VK_D) {
			goliath.moveEast();
		}
		//check if the position of rocks and david is the same then get the rock
		for (int i = 0 ; i < rock.size() ; i++ ) {
			if(david.getCurrentRoom() == rock.get(i).getCurrentRoom()) {
				david.pickUpStone();
				rock.get(i).setCurrentRoom(null);
			}
		}
		//ending message
		if(david.getCurrentRoom() == goliath.getCurrentRoom()) {
			if (david.isArmed() == true) {
				JOptionPane.showMessageDialog(null,"You Won!", "WINNER",JOptionPane.INFORMATION_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(null,"You need to get all the stones. Lose!", "LOSE",JOptionPane.INFORMATION_MESSAGE);
			}
			reset();
		}
		//to redraw to that position use repaint
		repaint();
	}
	//rest of key methods
	@Override
	public void keyTyped(KeyEvent e) {}
	@Override
	public void keyReleased(KeyEvent e) {}	
}