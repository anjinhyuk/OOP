import java.awt.*;

import javax.swing.*;

//This class is for icons
public abstract class Sprite implements Drawable{
	protected Room currentRoom;
	protected ImageIcon image;
	
	//set null position and image
	public Sprite() {
		currentRoom = null;
		image = null;
	}
	
	//bring positions from Room class
	public Room getCurrentRoom() {
		return currentRoom;
	}
	
	//use method to find position where the icon will be
	public void setCurrentRoom(Room r) {
		currentRoom = r;
	}
	
	//draw method to make icons drawn
	public void draw(Graphics g) {
		if (currentRoom != null) {
		Point p = currentRoom.getPosition();
		image.paintIcon(null,g,p.x+20,p.y+20);
		}
	}
	
	//moving logic
	public void moveSouth() {
		if (currentRoom.hasSouthExit() == true) {
			currentRoom = currentRoom.getSouthExit();
		}
	}
	
	public void moveNorth() {
		if (currentRoom.hasNorthExit() == true) {
			currentRoom = currentRoom.getNorthExit();
		}
	}
	
	public void moveEast() {
		if (currentRoom.hasEastExit() == true) {
			currentRoom = currentRoom.getEastExit();
		}
	}
	
	public void moveWest() {
		if (currentRoom.hasWestExit() == true) {
			currentRoom = currentRoom.getWestExit();
		}
	}
	
//	public void equal() {
//		if ()
//	}
	
}
