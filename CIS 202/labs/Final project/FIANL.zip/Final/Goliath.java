import java.awt.*;
import javax.swing.*;

//Goliath image class
public class Goliath extends Sprite{

	public Goliath () {
		super();
	image = new ImageIcon("Goliath.png");
	}
}