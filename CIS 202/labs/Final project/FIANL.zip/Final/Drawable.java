import java.awt.Graphics;
import java.util.ArrayList;

public interface Drawable {
	void draw(Graphics g);
}
