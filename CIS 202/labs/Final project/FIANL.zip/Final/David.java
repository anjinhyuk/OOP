import java.awt.*;
import javax.swing.*;

//David image class
public class David extends Sprite{
	
	private int numStones;
	
	public David() {
		super();
		image = new ImageIcon("David.png");
		numStones = 0;
	}
	
	public void pickUpStone() {
		numStones ++;
	}
	
	public boolean isArmed() {
		if (numStones == 5) {
			return true;
		} else {
			return false;
		}
	}
	
	public void reset() {
		numStones = 0;
	}
}
