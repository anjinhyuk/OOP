import java.awt.FlowLayout;
import javax.swing.*;

public class Frame {
  public static void main(String[] args) {
    JFrame aWindow = new JFrame("David & Goliath Game");
    JPanel panel = new Game();
    panel.setLayout(new FlowLayout());
    aWindow.add(panel);
    aWindow.setSize(500, 500);  
    aWindow.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    aWindow.setVisible(true);
   
  }
}