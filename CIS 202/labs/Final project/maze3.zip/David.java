
import javax.swing.ImageIcon;


public class David extends Sprite {
	
	
	public David() {
		super();
		image = new ImageIcon("david.png");
	}
}
