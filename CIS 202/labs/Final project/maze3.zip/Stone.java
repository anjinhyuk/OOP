
import javax.swing.ImageIcon;


public class Stone extends Sprite {

	public Stone() {
		super();
		image = new ImageIcon("stone.png");
	}
}
