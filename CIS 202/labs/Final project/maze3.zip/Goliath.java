
import javax.swing.ImageIcon;


public class Goliath extends Sprite {

	public Goliath() {
		super();
		image = new ImageIcon("goliath.png");
	}
}
