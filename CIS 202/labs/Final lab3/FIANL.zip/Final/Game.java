import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.*;

import javax.swing.*;

public class Game extends JApplet implements KeyListener {
	private Room room1;
	private Room room2;
	private Room room3;
	private Room room4;
	private Room room5;
	private Room room6;
	private Room room7;
	private Room room8;
	private Room room9;
	private Room room10;
	private Room room11;
	private Room room12;
	private Room room13;
	private Room room14;
	private Room room15;
	private Room room16;
	private Room room17;
	private Room room18;
	private Room room19;
	private Room room20;
	private Room room21;
	private Room room22;
	private Room room23;
	private Room room24;
	private Room room25;
	//use sprite images
	private David david;
	private Goliath goliath;
	private Stone stone1;
	private Stone stone2;
	private Stone stone3;
	private Stone stone4;
	private Stone stone5;
	//arraylist for stones
	ArrayList<Stone> rock = new ArrayList<Stone>();
	
	@Override
	public void init() {
	//ROOMS
	room1 = new Room(0,0);
	room2 = new Room(60,0);
	room3 = new Room(0,60);
	room4 = new Room(60,60);
	room5 = new Room(0,120);
	room6 = new Room(60,120);
	room7 = new Room(0,180);
	room8 = new Room(60,180);
	room9 = new Room(0,240);
	room10 = new Room(60,240);
	room11 = new Room(120,120);
	room12 = new Room(180,60);
	room13 = new Room(180,120);
	room14 = new Room(180,180);
	room15 = new Room(240,120);
	room16 = new Room(300,0);
	room17 = new Room(360,0);
	room18 = new Room(300,60);
	room19 = new Room(360,60);
	room20 = new Room(300,120);
	room21 = new Room(360,120);
	room22 = new Room(300,180);
	room23 = new Room(360,180);
	room24 = new Room(300,240);
	room25 = new Room(360,240);
	//initiate icons
	david = new David();
	goliath = new Goliath();
	stone1 = new Stone();
	stone2 = new Stone();
	stone3 = new Stone();
	stone4 = new Stone();
	stone5 = new Stone();
	//add stones in the arraylist
	rock.add(stone1);
	rock.add(stone2);
	rock.add(stone3);
	rock.add(stone4);
	rock.add(stone5);
	//PATH 1-10
	room1.setSouthExit(room3);
	room1.setEastExit(room2);
	room2.setSouthExit(room4);
	room4.setSouthExit(room6);
	room5.setEastExit(room6);
	room6.setEastExit(room11);
	room6.setSouthExit(room8);
	room8.setSouthExit(room10);
	room10.setWestExit(room9);
	room7.setSouthExit(room9);
	//PATH 11-20
	room11.setEastExit(room13);
	room13.setNorthExit(room12);
	room13.setSouthExit(room14);
	room13.setEastExit(room15);
	room15.setEastExit(room20);
	room18.setSouthExit(room20);
	room16.setSouthExit(room18);
	room16.setEastExit(room17);
	room17.setSouthExit(room19);
	room19.setSouthExit(room21);
	//PATH 21-25
	room20.setSouthExit(room22);
	room22.setSouthExit(room24);
	room24.setEastExit(room25);
	room23.setSouthExit(room25);
	room22.setEastExit(room23);
	//Room set for icons
	david.setCurrentRoom(room1);
	goliath.setCurrentRoom(room25);
	
	stone1.setCurrentRoom(room5);
	stone2.setCurrentRoom(room7);
	stone3.setCurrentRoom(room12);
	stone4.setCurrentRoom(room19);
	stone5.setCurrentRoom(room23);
	//interface 
	addKeyListener(this);
	
	}
	
	//background setting
	@Override
	public void paint (Graphics g) {
		int w = getWidth();
	    int h = getHeight();
	    g.setColor(Color.BLACK);
	    g.fillRect(0, 0, w, h);
	    //draw rooms
	    room1.draw(g);
	    room2.draw(g);
	    room3.draw(g);
	    room4.draw(g);
	    room5.draw(g);
	    room6.draw(g);
	    room7.draw(g);
	    room8.draw(g);
	    room9.draw(g);
	    room10.draw(g);
	    room11.draw(g);
	    room12.draw(g);
	    room13.draw(g);
	    room14.draw(g);
	    room15.draw(g);
	    room16.draw(g);
	    room17.draw(g);
	    room18.draw(g);
	    room19.draw(g);
	    room20.draw(g);
	    room21.draw(g);
	    room22.draw(g);
	    room23.draw(g);
	    room24.draw(g);
	    room25.draw(g);
	    
	    //david, goliath
	    david.draw(g);
	    goliath.draw(g);
	    //use for loop to print stones in arraylist
	    for (int i = 0; i < rock.size(); i++) {
		    rock.get(i).draw(g);
	    }
	    //to be safe
	    requestFocusInWindow();
	}
	
	//key pressed method to make characters move
	@Override
	public void keyPressed(KeyEvent e) {
		int k = e.getKeyCode();
		
		if (k == KeyEvent.VK_UP) {
			david.moveNorth();
		}
		if (k == KeyEvent.VK_DOWN) {
			david.moveSouth();
		}
		if (k == KeyEvent.VK_LEFT) {
			david.moveWest();
		}
		if (k == KeyEvent.VK_RIGHT) {
			david.moveEast();
		}
		
		if (k == KeyEvent.VK_NUMPAD8) {
			david.moveNorth();
		}
		if (k == KeyEvent.VK_NUMPAD4) {
			david.moveWest();
		}
		if (k == KeyEvent.VK_NUMPAD6) {
			david.moveEast();
		}
		if (k == KeyEvent.VK_NUMPAD2) {
			david.moveSouth();
		}
		if (k == KeyEvent.VK_W) {
			goliath.moveNorth();
		}
		if (k == KeyEvent.VK_S) {
			goliath.moveSouth();
		}
		if (k == KeyEvent.VK_A) {
			goliath.moveWest();
		}
		if (k == KeyEvent.VK_D) {
			goliath.moveEast();
		}
		//to redraw to that position use repaint
		repaint();
	}
	//rest of key methods
	@Override
	public void keyTyped(KeyEvent e) {}
	@Override
	public void keyReleased(KeyEvent e) {}	
	
}
