import java.awt.*;
import javax.swing.*;

//Goliath image class
public class Goliath extends Sprite{

	public Goliath () {
	image = new ImageIcon("Goliath.png");
	}
}