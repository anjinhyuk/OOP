import java.awt.*;
import javax.swing.*;

//David image class
public class David extends Sprite{
	
	public David() {
		super();
		image = new ImageIcon("David.png");
	}
}